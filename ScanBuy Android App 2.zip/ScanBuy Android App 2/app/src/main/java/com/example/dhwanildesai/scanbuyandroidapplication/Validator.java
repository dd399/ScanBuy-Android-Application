package com.example.dhwanildesai.scanbuyandroidapplication;

import java.util.regex.Pattern;


public class Validator {

    private static final String PHONE_REGEX = "^-?\\d*(\\.\\d+)?$";

    public boolean isEmpty (String values)
    {
        if ((values.trim()).equals("") || values.equals(null)) {
            return true;
        }
        else
        {
            return false;
        }
    }


    public boolean isNumber(String values) {
        String str = values.trim();
       // int num = Integer.parseInt(str);
        if(Pattern.matches(PHONE_REGEX,str))
        {
            return true;
        }
        else
            return false;
    }


}
