package com.example.dhwanildesai.scanbuyandroidapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {


    public static final String  TAG = "LoggingActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.dhwanildesai.scanbuyandroidapplication.R.layout.activity_main);

    }

    public void addBookonClick(View view){

        IntentIntegrator integrator = new IntentIntegrator(MainActivity.this);
        integrator.initiateScan();
    }

    public void onActivityResult(int requestCode,int resultCode,Intent intent){

        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,intent);
        if(scanResult != null)
        {
            String barcode;
            String type;
            Database db = new Database(this);

            barcode = scanResult.getContents();
            type = scanResult.getFormatName();

             if(db.getExistingBooks(barcode))
             {
                 Toast.makeText(MainActivity.this, "Hey!! this book is already exist check in the view book tab", Toast.LENGTH_LONG).show();
                 Intent i2;
                 BookDetails b2;
                 b2 = db.getSingleBook(barcode);
                 i2 = new Intent(this,View_Book.class);
                 i2.putExtra("bookdata", b2);

                 startActivity(i2);
             }
            else
             {
                 Intent intent1;
                 intent1 = new Intent(this, Registration_Activity.class);
                 intent1.putExtra("barC",barcode);
                 startActivity(intent1);
             }



        }

    }


    public void listOnClick(View view){

        Intent intent2 = new Intent(this, List_Activity.class);
        startActivity(intent2);
    }
}
