package com.example.dhwanildesai.scanbuyandroidapplication;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class List_Adaptor extends BaseAdapter {

    private final Context context;
    private  ArrayList<BookDetails> books=new ArrayList<>() ;


    public List_Adaptor(Context context, ArrayList<BookDetails> books) {

        // TODO Auto-generated constructor stub

        this.context=context;
        this.books=books;

    }

    @Override
    public int getCount() {
        return books.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=(LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView=inflater.inflate(R.layout.mylist, null, true);

        TextView txtTitle = (TextView) rowView.findViewById(R.id.listbookname);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
        TextView extratxt = (TextView) rowView.findViewById(R.id.listbookdata);

        BookDetails bookDetails =books.get(position);

        txtTitle.setText(bookDetails.getB_title());
        imageView.setImageResource(R.drawable.listicon);
        extratxt.setText("Barcode "+ bookDetails.getB_code());
        return rowView;

    };
}