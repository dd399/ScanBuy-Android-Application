package com.example.dhwanildesai.scanbuyandroidapplication;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class List_Activity extends AppCompatActivity{

    ListView list;
    Intent intent3;
    public static final String  TAG = "LoggingActivity";
    Database db;


    ArrayList<BookDetails> arrBook=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listactivity);

         intent3 = new Intent(this,View_Book.class);
            db = new Database(this);

        List<BookDetails> books = db.getAllBooks();

        int i=0;
        for(BookDetails b1 : books){

            arrBook.add(b1);
            i++;
        }


        List_Adaptor adapter=new List_Adaptor(List_Activity.this, arrBook);
        list=(ListView)findViewById(R.id.list);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                String Selecteditem= arrBook.get(position).getB_title();
                Toast.makeText(getApplicationContext(), Selecteditem, Toast.LENGTH_SHORT).show();
                BookDetails bookDetails =arrBook.get(position);
                intent3.putExtra("bookdata", bookDetails);

                startActivity(intent3);

            }
        });
    }
}
